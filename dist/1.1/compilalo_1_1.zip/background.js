chrome.runtime.onInstalled.addListener(() => {
  console.log('Compilalo.js installato con successo!');
});